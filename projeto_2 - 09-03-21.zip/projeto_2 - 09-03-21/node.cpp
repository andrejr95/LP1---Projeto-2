#include <iostream>
#include "node.hpp"

// Construtor
Node::Node(){

}

// Destrutor
Node::~Node(){

}